package org.hololink.labyrinth.solve;

import org.hololink.labyrinth.MazeDisplay;
import org.hololink.labyrinth.generate.ArbitraryMaze;
import org.hololink.labyrinth.generate.Maze;

import java.util.Random;

/**
 * Example d'un marcheur aléatoire.
 */
public class RandomWalker extends Walker {
    private Random r = new Random();

    public RandomWalker(Maze maze, MazeDisplay md) {
        super(maze, md);
    }

    @Override
    public void nextStep() {
        int choice = r.nextInt(4);
        if (choice == 0){
            if (!maze.isWall(state.getLoc(),state.getD())){
                state.move();
            }
        } else if (choice == 1){
            state.turnRight();
        } else if (choice == 2){
            state.turnLeft();
        } else {
            state.turnAround();
        }
    }

    public static void main(String[] args) {
        Maze maze = new ArbitraryMaze();
        RandomWalker rw = new RandomWalker(maze, new MazeDisplay(maze));
        rw.walk();
    }
}
