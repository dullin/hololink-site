package org.hololink.labyrinth.solve;

import org.hololink.labyrinth.MazeDisplay;
import org.hololink.labyrinth.generate.ArbitraryMaze;
import org.hololink.labyrinth.generate.Maze;
import org.hololink.position.Direction;

/**
 * Exemple d'un marcheur fantôme.
 */
public class GhostWalker extends Walker {
    public GhostWalker(Maze maze, MazeDisplay md) {
        super(maze, md);
    }

    @Override
    public void nextStep() {
        if (maze.goal().getCol() < state.getLoc().getCol()){
            state.move(Direction.WEST);
        } else if (maze.goal().getCol() > state.getLoc().getCol()){
            state.move(Direction.EAST);
        } else if (maze.goal().getRow() < state.getLoc().getRow()){
            state.move(Direction.NORTH);
        } else if (maze.goal().getRow() > state.getLoc().getRow()){
            state.move(Direction.SOUTH);
        }
    }

    public static void main(String[] args) {
        Maze maze = new ArbitraryMaze();
        GhostWalker gw = new GhostWalker(maze, new MazeDisplay(maze));
        gw.walk();
    }
}
