package org.hololink.labyrinth.solve;

import org.hololink.labyrinth.MazeDisplay;
import org.hololink.labyrinth.generate.Maze;

public abstract class Walker {
    WalkerState state;
    Maze maze;
    MazeDisplay md;

    public Walker(Maze maze, MazeDisplay md) {
        this.maze = maze;
        this.md = md;

        state = maze.start();
    }

    public void walk(){
        md.addState(state);
        md.display();

        while(!state.getLoc().equals(maze.goal())){
            nextStep();

            md.addState(state);
            md.display();

            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public abstract void nextStep();
}
