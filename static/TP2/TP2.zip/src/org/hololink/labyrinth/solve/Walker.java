package org.hololink.labyrinth.solve;

import org.hololink.labyrinth.MazeDisplay;
import org.hololink.labyrinth.generate.Maze;

/**
 * Le marcheur dans un labyrinthe.
 * Le marcheur permet de marche dans un labyrinthe.
 * Le marcheur à besoin de la méthode <code>nextStep</code> qui doit faire bouger le <code>WalkerState</code>
 * avec <code>move</code>.
 * Pour activer notre algorithme, on utilise la méthode <code>walk</code>.
 */
public abstract class Walker {
    protected WalkerState state;
    protected Maze maze;
    private MazeDisplay md;

    public Walker(Maze maze, MazeDisplay md) {
        this.maze = maze;
        this.md = md;

        state = maze.start();
    }

    public void walk(){
        md.addState(state);
        md.display();

        while(!state.getLoc().equals(maze.goal())){
            nextStep();

            md.addState(state);
            md.display();

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Fait bouger le marcheur vers sa prochaine étape.
     */
    public abstract void nextStep();
}
