package org.hololink.labyrinth.solve;

import org.hololink.position.Direction;
import org.hololink.position.Location;

public class WalkerState{
    private Location loc;
    private Direction d;

    public WalkerState(Location loc, Direction d) {
        this.loc = loc;
        this.d = d;
    }

    public WalkerState(WalkerState state){
        this.d = state.d;
        this.loc = new Location(state.loc.getRow(), state.loc.getCol());
    }

    public void turnRight(){
        d = d.turnRight();
    }

    public void turnLeft(){
        d = d.turnLeft();
    }

    public void turnAround(){
        d = d.turnAround();
    }

    public void move(){
        loc.move(d.getRow(), d.getCol());
    }

    public void move(Direction d){
        loc.move(d.getRow(), d.getCol());
        this.d = d;
    }

    public Direction toRight(){
        return d.turnRight();
    }

    public Direction toLeft(){
        return d.turnRight();
    }

    public Direction toBack(){
        return d.turnRight();
    }

    public Location neighborTo(Direction d){
        return new Location(loc, d.getRow(), d.getCol());
    }

    public Location getLoc() {
        return loc;
    }

    public Direction getD() {
        return d;
    }
}
