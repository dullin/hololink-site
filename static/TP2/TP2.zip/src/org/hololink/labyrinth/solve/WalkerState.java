package org.hololink.labyrinth.solve;

import org.hololink.position.Direction;
import org.hololink.position.Location;

/**
 * Représente l'état d'un marcheur.
 * Contient une <code>Location</code> et une <code>Direction</code>.
 */
public class WalkerState{
    private Location loc;
    private Direction d;

    public WalkerState(Location loc, Direction d) {
        this.loc = loc;
        this.d = d;
    }

    public WalkerState(WalkerState state){
        this.d = state.d;
        this.loc = new Location(state.loc.getRow(), state.loc.getCol());
    }

    /**
     * Tourne le marcheur vers la droite.
     */
    public void turnRight(){
        d = d.turnRight();
    }

    /**
     * Tourne le marcheur vers la gauche.
     */
    public void turnLeft(){
        d = d.turnLeft();
    }

    /**
     * Tourne le marcheur sur lui-même.
     */
    public void turnAround(){
        d = d.turnAround();
    }

    /**
     * Bouge le marcheur dans sa direction courante.
     */
    public void move(){
        loc.move(d.getRow(), d.getCol());
    }

    /**
     * Bouge le marcheur dans une direction donné. Oriente le marcheur
     * dans cette direction.
     * @param d La direction de déplacement.
     */
    public void move(Direction d){
        loc.move(d.getRow(), d.getCol());
        this.d = d;
    }

    /**
     * La <code>Location</code> du marcheur.
     * @return La <code>Location</code>.
     */
    public Location getLoc() {
        return loc;
    }

    /**
     * La <code>Direction</code> du marcheur.
     * @return La <code>Direction</code>.
     */
    public Direction getD() {
        return d;
    }
}
