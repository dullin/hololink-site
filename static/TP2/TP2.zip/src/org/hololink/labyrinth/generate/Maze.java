package org.hololink.labyrinth.generate;

import org.hololink.labyrinth.solve.WalkerState;
import org.hololink.position.Direction;
import org.hololink.position.Location;

import java.util.*;

/**
 * Le <code>Maze</code> est la représentation d'un Labyrinthe. Cette classe abstraire
 * offrent les services essentieles pour construire des labyrinthes. La création se fait
 * à partir d'un nombre de ligne et colonne initiale dans le constructeur suivit d'un appel
 * à la méthode abstraite <code>generate</code> qui doit contenir le code pour générer le <code>Maze</code>.
 *
 * Pour la génération du labyrinthe, la méthode <code>carveWall</code> permet de creuser des trous
 * à partir d'une <code>Location</code> donné dans un <code>Direction</code> précise.
 *
 * Pour la détection d'emplacement, les méthodes <code>isWall</code> et <code>isWithinBounds</code> sont présentes.
 * La première permet de savoir si d'une <code>Location</code> donné dans un <code>Direction</code> on retrouve un mur.
 * La deuxième permet de tester si une <code>Location</code> se trouve à l'intérieur des bornes du labyrinthe.
 */
public abstract class Maze {

    private Map<Location, HashSet<Direction>> holes;
    private int nRow, nCol;

    /**
     * Crée un <code>Maze</code> d'une taille donné.
     * @param nRow Le nombre de ligne.
     * @param nCol Le nombre de colonne.
     */
    public Maze(int nRow, int nCol){
        this.nRow = nRow;
        this.nCol = nCol;
        holes = new HashMap<Location, HashSet<Direction>>();

        generate();
    }

    public int getnCol() {
        return nCol;
    }

    public int getnRow() {
        return nRow;
    }

    /**
     * Méthode de génération du <code>Maze</code> qui devra être implémenté.
     */
    public abstract void generate();

    /**
     * Donne l'état initiale du <code>WalkerState</code> qui peut se promener
     * dans le <code>Maze</code>. On part toujours de la <code>Location</code> 0,0
     * en pointant le sud.
     * @return L'état initiale.
     */
    public WalkerState start(){
        return new WalkerState(new Location(0,0), Direction.SOUTH);
    }

    /**
     * La position de sortie du <code>Maze</code>. Est toujours la postition en base à droite.
     * @return La position de la sortie du labyrinthe.
     */
    public Location goal(){
        return new Location(nRow - 1, nCol - 1);
    }

    /**
     * Détermine si un mur est présent à partir d'une <code>Location</code> donné dans un <code>Direction</code> précise.
     * @param l La <code>Location</code> d'où on regarde.
     * @param d La <code>Direction</code> dans laquelle on regarde.
     * @return Si il y a un mur à l'endroit donné.
     */
    public boolean isWall(Location l, Direction d){
        if (holes.containsKey(l)){
            return ! holes.get(l).contains(d);
        } else {
            return true;
        }
    }

    /**
     * Creuse un mur à partir d'une <code>Location</code> donné dans un <code>Direction</code> précise.
     * @param l La <code>Location</code> d'où on regarde.
     * @param d La <code>Direction</code> dans laquelle on regarde.
     */
    protected void carveWall(Location l, Direction d){
        Location newLoc = new Location(l, d);
        if (isWithinBounds(l) && isWithinBounds(newLoc)){
            addHole(l, d);
            addHole(newLoc, d.turnAround());
        }
    }

    private void addHole(Location l, Direction d){
        if (isWithinBounds(l)){
            if (!holes.containsKey(l)){
                holes.put(l, new HashSet<Direction>());
            }
            holes.get(l).add(d);
        }
    }

    /**
     * Détermine si une <code>Location</code> est à l'intérieur des bornes du labyrinthe.
     * @param l La <code>Location</code> à étudier.
     * @return Si la <code>Location</code> est à l'intérieur des bornes du labyrinthe.
     */
    public boolean isWithinBounds(Location l){
        return l.getRow() >= 0 && l.getRow() < nRow
                && l.getCol() >= 0 && l.getCol() < nCol;
    }

}
