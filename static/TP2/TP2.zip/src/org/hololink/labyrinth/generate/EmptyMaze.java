package org.hololink.labyrinth.generate;

import org.hololink.labyrinth.MazeDisplay;
import org.hololink.position.Direction;
import org.hololink.position.Location;

/**
 * Exemple d'une extension de la classe <code>Maze</code>. Creuse tous les murs possible.
 */
public class EmptyMaze extends Maze {
    public EmptyMaze(int nRow, int nCol) {
        super(nRow, nCol);
    }

    @Override
    public void generate() {
        for (int i = 0; i < getnRow(); i++) {
            for (int j = 0; j < getnCol(); j++) {
                Location currentLoc = new Location(i,j);
                Location toEast = new Location(currentLoc, Direction.EAST);
                Location toSouth = new Location(currentLoc, Direction.SOUTH);
                if (isWithinBounds(toEast)){
                    carveWall(currentLoc, Direction.EAST);
                }
                if (isWithinBounds(toSouth)){
                    carveWall(currentLoc, Direction.SOUTH);
                }
            }
        }
    }

    public static void main(String[] args) {
        MazeDisplay md = new MazeDisplay(new EmptyMaze(10, 10));
        md.display();
    }
}
