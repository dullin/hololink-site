package org.hololink.labyrinth.generate;

import org.hololink.labyrinth.MazeDisplay;
import org.hololink.position.Direction;
import org.hololink.position.Location;

/**
 * Exemple d'une extension de la classe <code>Maze</code>
 */
public class ArbitraryMaze extends Maze {
    public ArbitraryMaze() {
        super(3, 3);
    }

    @Override
    public void generate() {
        carveWall(new Location(0,0), Direction.SOUTH);
        carveWall(new Location(1,1), Direction.WEST);
        carveWall(new Location(1,1), Direction.NORTH);
        carveWall(new Location(0,1), Direction.EAST);
        carveWall(new Location(2,1), Direction.NORTH);
        carveWall(new Location(2,1), Direction.WEST);
        carveWall(new Location(2,1), Direction.EAST);
        carveWall(new Location(1,2), Direction.WEST);
    }

    public static void main(String[] args) {
        MazeDisplay md = new MazeDisplay(new ArbitraryMaze());
        md.display();
    }
}
