package org.hololink.labyrinth;

import org.hololink.labyrinth.generate.EmptyMaze;
import org.hololink.labyrinth.generate.Maze;
import org.hololink.labyrinth.solve.WalkerState;
import org.hololink.position.Direction;
import org.hololink.position.Location;

import java.util.HashMap;
import java.util.HashSet;

/**
 * <code>MazeDisplay</code> permet de gérer l'affichage d'un <code>Maze</code> ainsi qu'une série <code>WalkerState</code>.
 * La méthode principale est <code>display</code> qui affiche le <code>Maze</code> avec les différents états
 * du <code>WalkerState</code>. Pour ajouter des états du walker, on utilise la méthode <code>addState</code>.
 */
public class MazeDisplay {
    private Maze maze;
    private HashSet<Location> walkerPath = new HashSet<>();
    private WalkerState currentState;

    /**
     * Crée un nouveau <code>MazeDisplay</code>. Doit recevoir un <code>Maze</code> initiale.
     * @param maze Le <code>Maze</code> initiale.
     */
    public MazeDisplay(Maze maze) {
        this.maze = maze;
        currentState = maze.start();
    }

    /**
     * Affiche le <code>Maze</code> et les états de <code>WalkerState</code> ajoutés.
     */
    public void display(){
        System.out.println(this);
    }

    @Override
    public String toString() {
        StringBuilder strMaze = new StringBuilder();

        strMaze.append("Next step:\n");
        // Top line
        for (int j = 0; j < maze.getnCol() * 2 + 1; j++) {
            strMaze.append("#");
        }
        strMaze.append("\n");

        for (int i = 0; i < maze.getnRow(); i++) {
            strMaze.append("#");
            // Display real cells
            for (int j = 0; j < maze.getnCol(); j++) {
                Location loc = new Location(i, j);
                if (loc.equals(currentState.getLoc())){
                    strMaze.append(currentState.getD());
                }
                else if (walkerPath.contains(loc)){
                    strMaze.append(".");
                } else {
                    strMaze.append(" ");
                }
                strMaze.append(maze.isWall(new Location(i,j),Direction.EAST) ? "#" : " ");
            }
            strMaze.append("\n#");

            // Display wall row
            for (int j = 0; j < maze.getnCol(); j++) {
                Location loc = new Location(i, j);
                strMaze.append(maze.isWall(loc, Direction.SOUTH) ? "#" : " ");
                strMaze.append("#");
            }
            strMaze.append("\n");
        }

        strMaze.append("\n");

        return strMaze.toString();
    }

    /**
     * Ajoute une état à la liste des états à afficher.
     * @param state Le nouvel état.
     */
    public void addState(WalkerState state){
        WalkerState newState = new WalkerState(state);
        currentState = newState;
        walkerPath.add(newState.getLoc());
    }

    public static void main(String[] args) {
        MazeDisplay md = new MazeDisplay(new EmptyMaze(10, 10));

        md.addState(new WalkerState(new Location(1,1), Direction.NORTH));
        // On peut écraser un state.
        md.addState(new WalkerState(new Location(1,1), Direction.SOUTH));

        md.addState(new WalkerState(new Location(9,9), Direction.NORTH));

        md.display();
    }
}
