package org.hololink.position;

import java.util.Objects;

/**
 * Une <code>Location</code> représente un emplacement sur une grille. Le représentation
 * utilise un numéro de ligne et un numéro de colonne entier pour indiquer différentes
 * <code>Location</code>.
 */
public class Location implements Comparable {
    private int row;
    private int col;

    /**
     * Crée une <code>Location à partir d'une ligne et colonne initiale.</code>
     * @param row La ligne de l'emplacement.
     * @param col La colonne de l'emplacement.
     */
    public Location(int row, int col) {
        this.row = row;
        this.col = col;
    }

    /**
     * Crée une <code>Location</code> à partir d'une <code>Location</code> initale
     * et d'un delta en ligne et colonne.
     * @param loc La <code>Location</code> initiale.
     * @param dRow Le delta de ligne.
     * @param dCol Le delta de colonne.
     */
    public Location(Location loc, int dRow, int dCol){
        this.row = loc.row;
        this.col = loc.col;
        move(dRow, dCol);

    }

    /**
     * Crée une <code>Location</code> à partir d'une <code>Location</code> initiale
     * et une <code>Direction</code> comme delta.
     * @param loc La <code>Location</code> initiale.
     * @param d Le delta de direction.
     */
    public Location(Location loc, Direction d){
        this.row = loc.row + d.getRow();
        this.col = loc.col + d.getCol();
    }

    /**
     * Bouge une <code>Location</code>.
     * @param dRow Le delta de ligne.
     * @param dCol Le delta de colonne.
     */
    public void move(int dRow, int dCol){
        row += dRow;
        col += dCol;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Location location = (Location) o;
        return row == location.row &&
                col == location.col;
    }

    @Override
    public int hashCode() {
        return Objects.hash(row, col);
    }


    @Override
    public int compareTo(Object o) {
        if (this == o) return 0;
        if (o == null || getClass() != o.getClass()) return 1;
        Location location = (Location) o;

        if (col < location.col){
            return -1;
        } else if (col > location.col) {
            return 1;
        }

        if (row < location.row){
            return -1;
        } else if (row > location.row) {
            return 1;
        }

        return 0;
    }

    @Override
    public String toString() {
        return "Location{" +
                "row=" + row +
                ", col=" + col +
                '}';
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public static void main(String[] args) {
        Location l = new Location(3,4);
        System.out.println(l);

        Location l2 = new Location(l, 1, -1);
        System.out.println(l);
        System.out.println(l2);
    }
}
