package org.hololink.position;

import java.util.Arrays;
import java.util.Random;

/**
 * Une <code>Direction</code> est une énumération qui représente les directions cardinales.
 * <ul>
 *     <li>NORTH</li>
 *     <li>EAST</li>
 *     <li>SOUTH</li>
 *     <li>WEST</li>
 * </ul>
 *
 * Des méthodes publiques nous permet de trouver les directions à gauche, droite et derrière une
 * direction courante. Une dernière méthode <code>shuffled</code> permet d'avoir un tableau de directions
 * mélangé de manière aléatoire.
 */

// Used https://codereview.stackexchange.com/a/42828
public enum Direction {

    // use magic numbers to set the ordinal (used for rotation),
    // and the dx and dy of each direction.
    NORTH(0, -1, 0),
    EAST(1, 0, 1),
    SOUTH(2, 1, 0),
    WEST(3, 0, -1);


    private final int r90index, r180index, r270index;
    private final int row, col;
    private static Random random;


    Direction(int ordinal, int row, int col) {
        // from the ordinal, dx, and dy, we can calculate all the other constants.
        this.row = row;
        this.col = col;
        this.r90index  = (ordinal + 1) % 4;
        this.r180index = (ordinal + 2) % 4;
        this.r270index = (ordinal + 3) % 4;
    }

    // Rotate 90 degrees clockwise

    /**
     * Tourne vers la droite.
     * @return La direction à droite de la direction courante.
     */
    public Direction turnRight() {
        return values()[r90index];
    }

    // Rotate 180 degrees

    /**
     * Tourne sur lui-même
     * @return La direction derrière la direction courante.
     */
    public Direction turnAround() {
        return values()[r180index];
    }

    // Rotate 270 degrees clockwise (90 counterclockwise)

    /**
     * Tourne vers la gauche.
     * @return La direction à gauche de la direction courante.
     */
    public Direction turnLeft() {
        return values()[r270index];
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    @Override
    public String toString() {
        switch (this){
            case NORTH:
                return "^";
            case SOUTH:
                return "v";
            case EAST:
                return ">";
            case WEST:
                return "<";

        }
        return ".";
    }

    /**
     * Mélange les directions aléatoirement.
     * @return Tableau des 4 directions mélangées aléatoirement.
     */
    public static Direction[] shuffled() {
        Direction[] array = Direction.values();
        if (random == null) random = new Random();

        int count = array.length;
        for (int i = count; i > 1; i--) {
            swap(array, i - 1, random.nextInt(i));
        }

        return array;
    }

    private static void swap(Direction[] array, int i, int j) {
        Direction temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }


    public static void main(String[] args) {
        Direction d = NORTH;

        System.out.println(d);
        System.out.println(NORTH.turnAround());
        System.out.println(Arrays.toString(shuffled()));
    }

}
