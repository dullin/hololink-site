import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.Stack;

import static java.awt.Color.*;

public class HanoiTowerComponent extends JComponent {
    private Stack<Integer> rings = new Stack<>();
    private Color[] ringColors = {BLUE, CYAN, GRAY, ORANGE, RED, WHITE, MAGENTA, PINK};

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        RoundRectangle2D bottom = new RoundRectangle2D.Double( 20, 270, 160, 20.0, 10.0, 10.0);
        RoundRectangle2D pillar = new RoundRectangle2D.Double(95, 30, 10, 250, 10, 10);
        g2.fill(bottom);
        g2.fill(pillar);
        Dimension d = new Dimension(200,350);

        for (int i = 0; i < rings.size(); i++) {
            int ringSize = rings.get(i);
            int width = ringSize * 20 + 20;
            Rectangle2D ring = new Rectangle2D.Double(100- width/2, 270 - (i+1) * 20, width, 20);
            g2.setColor(ringColors[ringSize]);
            g2.fill(ring);
        }

        setSize(d);
        setMinimumSize(d);
        setMaximumSize(d);
    }

    /**
     * Vide la colonne.
     */
    public void clear(){
        rings.clear();
        repaint();
    }

    /**
     * Initialise la tour avec un nombre d'anneaux.
     * @param nRing Le nombre d'anneaux à ajouter à la tour.
     */
    public void reset(int nRing){
        clear();
        for (int i = nRing -1; i >= 0; i--) {
            rings.add(i);
        }
        repaint();
    }

    /**
     * Initialise la tour avec 5 anneaux.
     */
    public void reset(){
        reset(5);
    }

    /**
     * Ajoute une anneau à la tour. Ne fait pas de gestion d'erreur.
     * @param ringSize La taille de l'anneau. Va de 0 à 7.
     */
    public void push(int ringSize){
        rings.push(ringSize);
        repaint();
    }

    /**
     * Pop l'anneau de la tour.
     * @return La taille de l'anneau.
     */
    public int pop(){
        int size = rings.pop();
        repaint();
        return size;
    }

    /**
     * Peek la taille de l'anneau.
     * @return La taille de l'anneau sur le dessus de la tour.
     */
    public int peek(){
        return rings.peek();
    }

    /**
     * Détermine si la tour est vide.
     * @return Si la tour est vide.
     */
    public boolean isEmpty(){
        return rings.isEmpty();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        Dimension d = new Dimension(200,350);
        frame.setSize(d);
        frame.setMinimumSize(d);
        frame.setMaximumSize(d);


        HanoiTowerComponent hanoiTowerComponent = new HanoiTowerComponent();
        hanoiTowerComponent.reset(8);
        frame.add(hanoiTowerComponent);

        frame.setVisible(true);

    }
}
