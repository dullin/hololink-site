import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;

import static java.awt.Color.*;

public class HanoiRing extends JComponent {
    private int ringSize = -1;

    private Color ringColors[] = {BLUE, CYAN, GRAY, ORANGE, RED, WHITE, MAGENTA, PINK, YELLOW};

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (ringSize != -1){
            Graphics2D g2 = (Graphics2D) g;

            int width = ringSize * 20 + 20;
            Rectangle2D ring = new Rectangle2D.Double(getWidth()/2 - width/2, getHeight()/2 - 15/2, width, 15);
            g2.setColor(ringColors[ringSize]);

            g2.fill(ring);
        }

    }

    /**
     * Retourne la taille de l'anneau.
     * @return Taille de l'anneau.
     */
    public int getRingSize() {
        return ringSize;
    }

    /**
     * Modifie la taille de l'anneau.
     * @param ringSize Taille de l'anneau
     */
    public void setRingSize(int ringSize) {
        this.ringSize = ringSize;
        repaint();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame();

        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setSize(600,350);

        HanoiRing hanoiRing = new HanoiRing();
        hanoiRing.setRingSize(3);
        frame.add(hanoiRing);

        frame.setVisible(true);
    }

}
