import javax.swing.*;
import java.util.ArrayList;
import java.security.InvalidParameterException;
import java.util.EmptyStackException;

public class HanoiController {

    // Singleton
    private static HanoiController instance = new HanoiController();
    private HanoiController(){};
    public static HanoiController getInstance(){
        return instance;
    }

    // Controller
    HanoiRing topRing;
    ArrayList<HanoiTowerComponent> towers = new ArrayList<>();
    JFrame view;

    public void setView(JFrame view) {
        this.view = view;
    }

    public void setTopRing(HanoiRing topRing) {
        this.topRing = topRing;
    }

    public void addTower(HanoiTowerComponent tower){
        towers.add(tower);
    }

    public void reset(int nRing){
        towers.get(0).reset(nRing);
        towers.get(1).clear();
        towers.get(2).clear();
    }

    /**
     * Gestion du bouton Select d'une des tours de Hanoi. La gestion dépend de l'anneau sélectionné courant.
     * Si aucun anneau n'est sélectionné, on "pop" l'anneau de la tour et on l'assigne dans l'anneau sélectionné.
     * Si un anneau est déjà sélectionné, on le "push" sur la tour sélectionnée.
     *
     * Cette fonction fait la gestion des erreurs possibles suivantes :
     * S'il n'y a pas d'anneau sélectionné et que la tour sélectionnée est vide, une boite de dialogue indique que la
     * tour est vide.
     * Si l'on tente d'empiler un anneau sur une tour contenant un anneau plus petit, on annule l'opération et on indique
     * que la tour ne peut pas recevoir l'anneau.
     * @param towerNumber Le numéro de la tour qui à été sélectionnée, va de 0 à 2.
     */
    public void handleSelect(int towerNumber){

    }

    /**
     * Gestion de la création d'une nouvelle partie. Affiche une boite de saisit qui demande le nombre d'anneaux
     * à avoir dans la partie. Si la valeur est invalide (pas un nombre ou en dehors de 1 à 8), on affiche un message
     * d'erreur et l'on recommence la saisie.
     */
    public void handleNewGame(){

    }
}
