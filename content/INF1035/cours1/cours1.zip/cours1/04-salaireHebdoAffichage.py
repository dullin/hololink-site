
# Saisit des données initiales
heuresTravailler = float(input("Entrez le nombre d'heures travailler : "))
tauxHoraire = float(input("Entrez le nombre taux horaire : "))

# Calcul du salaire Brut
salaireHebdomadaireBrut = heuresTravailler * tauxHoraire

# Calcul du salaire net
taux_imposition = 0.18
salaireHebdomadaireNet = salaireHebdomadaireBrut - salaireHebdomadaireBrut * taux_imposition

# Affichage final
#print("Mon salaire hebdomadaire brut est {:.2f} et mon salaire net est {:.2f}".format(salaireHebdomadaireBrut, salaireHebdomadaireNet))
print("Mon salaire hebdomadaire brut est", salaireHebdomadaireBrut, "et mon salaire net est ", salaireHebdomadaireNet)