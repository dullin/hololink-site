
# Saisit des données initiales
heuresTravailler = float(input("Entrez le nombre d'heures travailler : "))
tauxHoraire = float(input("Entrez le nombre taux horaire : "))

# Calcul du salaire Brut
salaireHebdomadaireBrut = heuresTravailler * tauxHoraire
print("Mon salaire hebdomadaire brut")
print(salaireHebdomadaireBrut)

# Calcul du salaire net
taux_imposition = 0.18
salaireHebdomadaireNet = salaireHebdomadaireBrut - salaireHebdomadaireBrut * taux_imposition
print("Mon salaire hebdomadaire net")
print(salaireHebdomadaireNet)