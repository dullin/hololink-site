
# Saisit des données initiales
heuresTravailler = float(input("Entrez le nombre d'heures travailler : "))
tauxHoraire = float(input("Entrez le nombre taux horaire : "))

# Calcul du salaire Brut
salaireHebdomadaireBrut = heuresTravailler * tauxHoraire
# Ajout du temps supplémentaire
if heuresTravailler > 40:
    # Le \ permet de continuer une instruction sur une autre ligne
    salaireHebdomadaireBrut = salaireHebdomadaireBrut + \
        tauxHoraire * (heuresTravailler - 40) * 0.5

# Calcul du salaire net
taux_imposition = 0.18
salaireHebdomadaireNet = salaireHebdomadaireBrut - salaireHebdomadaireBrut * taux_imposition

# Affichage final
print("Mon salaire hebdomadaire brut est {:.2f} et mon salaire net est {:.2f}"\
      .format(salaireHebdomadaireBrut, salaireHebdomadaireNet))
