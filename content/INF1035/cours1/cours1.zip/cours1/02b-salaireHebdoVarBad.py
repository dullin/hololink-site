a = 18
b = 45
c = a * b
print("Mon salaire hebdomadaire brut")
print(c)
d = 0.18
e = c - c * d
print("Mon salaire hebdomadaire net")
print(e)