# Script pour calculer le salaire
# hebdomadaire d'une personne.

print("Mon salaire hebdomadaire")
print(6 * 20.5)