"""Saisit un nombre et affiche si ce nombre est premier. Un nombre premier
à seulement 1 et lui-même comme diviseur. L'affichage prendre la forme
"NOMBRE est premier" ou "NOMBRE pas premier."

Example:
  ::

        Le nombre a regarder : 17
        17 est premier.
"""

if __name__ == '__main__':
    saisie = int(input('Le nombre a regarder : '))

    # Suppose un nombre premier
    estPremier = True

    # Test tous les nombre autres que 1 et le nombre saisi.
    for i in range(2, saisie):
        # Test si le nombre est un diviseur.
        if saisie % i == 0:
            # Le nombre n'est pas premier si on trouve un diviseur.
            estPremier = False

    # Affiche si le nombre est premier ou pas.
    if estPremier:
        print(saisie, 'est premier.')
    else:
        print(saisie, "n'est pas premier.")
