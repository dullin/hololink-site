"""Saisit un nombre et affiche à l'écran un triangle rectangle composé
d'etoiles dont la base et la hauteur correspondent au nombre saisit.

Example:
  ::

        Veuillez entrer la taille du triangle d'étoiles: 5
        *
        **
        ***
        ****
        *****
"""

if __name__ == '__main__':
    # Saisit le nombre entier.
    nEtoiles = int(input('Veuillez entrer la taille du triangle d''étoiles: '))

    # Pour chaque ligne.
    for iLigne in range(nEtoiles):
        # Affiche le bon nombre d'étoiles.
        print('*' * (iLigne + 1))
        # Saute une ligne après les étoiles.
