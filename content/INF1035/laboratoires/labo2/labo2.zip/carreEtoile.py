"""Saisit la dimension d'un carré. Affiche un carré d'étoile (*) à l'écran
avec un nombre de ligne et un nombre de colonnes déterminé par la saisit.

Example:
  ::

        Quel est la dimension du carre : 5
        *****
        *****
        *****
        *****
        *****
"""

if __name__ == '__main__':
    # Saisit la dimension du carre d'etoiles.
    dimension = int(input('Quel est la dimension du carre : '))

    for i in range(dimension):
        # On peut "multiplier" un chaine
        print('*' * dimension)

    print('Autre méthode')

    # Manière qui démontre l'utilisation de boucles imbriqués
    # Pour chaque ligne.
    for i in range(dimension):
        # Affiche les étoiles d'une ligne.
        for j in range(dimension):
            print('*', end='')
        # Saut de ligne après chaque ligne d'étoiles.
        print('')

