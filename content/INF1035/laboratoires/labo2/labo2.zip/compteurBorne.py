"""Saisit un nombre minimum, un nombre maximum et un intervalle. Avec une
boucle while, affiche tous les nombres entre le nombre minimum et le
nombre maximum en utilisant des sauts de l'intervalle.

Example:
  ::

      Entrez le minimum : 3
      Entrez le maximum : 13
      Entrez l'intervalle : 2
      3
      5
      7
      9
      11
      13
"""

if __name__ == '__main__':
    # Saisit le maximum, minimum et l'intervalle.
    minimum = int(input('Entrez le minimum : '))
    maximum = int(input('Entrez le maximum : '))
    intervalle = int(input('Entrez l''intervalle : '))

    # Initialise le compteur au minimum.
    compteur = minimum

    while compteur <= maximum:
        # Affiche l'état du compteur.
        print(compteur)
        # Somme cumulative de l'intérvale.
        compteur = compteur+intervalle

