"""Saisit un nombre et affiche tous les diviseurs de ce nombre. Note : La
fonction mod permet d'aider à trouver si un nombre est un diviseur d'un
autre.

Example:
  ::

      Veuillez entrer un nombre entier: 14
      Les diviseurs du nombre 14 sont:
      1
      2
      7
      14
"""

if __name__ == '__main__':
    # Saisit le nombre entier.
    saisie = int(input('Veuillez entrer un nombre entier: '))

    # Début du message.
    print('Les diviseurs du nombre', saisie, 'sont:')

    # Parcours tous les nombre entre 1 et la saisi.
    for i in range(1, saisie+1):
        # Test pour savoir si c'est une diviseur du nombre et l'affiche.
        if saisie % i == 0:
            print(i)
