"""Faire afficher dans chacunes des boucles for suivantes :

+----------+-----------+------------+-------------+
| Boucle 1 | Boucle 2  | Boucle 3   | Boucle 4    |
+==========+===========+============+=============+
| Début: 1 | Début: 3  | Début: 100 | Début: -100 |
+----------+-----------+------------+-------------+
| Saut: 1  | Saut: -1  | Saut: 50   | Saut: 50    |
+----------+-----------+------------+-------------+
| Fin: 3   | Fin: -2   | Fin: 200   | Fin: 100    |
+----------+-----------+------------+-------------+

Example:
  ::

      Boucle 1
      1
      2
      3
      Boucle 2
      3
      2
      1
      0
      -1
      -2
      Boucle 3
      100
      150
      200
      Boucle 4
      -100
      -50
      0
      50
      100
"""

if __name__ == '__main__':
    # Identification de la boucle.
    print('Boucle 1')

    # Boucle de 1 à 3 et incrémente de 1
    # à chaque itération.
    for i in range(1, 4):
        print(i)

    # Identification de la boucle.
    print('Boucle 2')

    # Boucle de 3 à -2 et incrémente de -1
    # à chaque itération.
    for i in range(3, -3, -1):
        print(i)

    # Identification de la boucle.
    print('Boucle 3')

    # Boucle de 100 a 200 et incrémente de 50
    # à chaque itération.
    for i in range(100,201, 50):
        print(i)


    # Identification de la boucle.
    print('Boucle 4')

    # boucle de -100 a 100 par increment de 50
    for i in range(-100, 101, 50):
        # affiche le compteur
        print(i)

