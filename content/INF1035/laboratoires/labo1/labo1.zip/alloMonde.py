"""Affiche le message "Allo monde!" avec un
saut de ligne dans la fenêtre de commande.

Example:
  ::

        Allo monde!
"""

if __name__ == '__main__':
    # Affiche le message et on saute une ligne.
    print('Allo monde!')
