"""Demande à l'utilisateur de saisir trois nombres. Le script affiche le
plus petit des trois nombres. Le script doit aussi affiché un message si
il y a eu égalité sur le plut petit nombre. L'affichage de base prends la forme
"Plus petit : NOMBRE" suivi d'un saut de ligne. L'affichage de l'égalité
prends la forme "Il y a eu égalité." suivi d'un saut de ligne.

Example:
  ::

      Entrez un nombre: 34
      Entrez un autre nombre: 67
      Entrez un autre nombre: 32
      Plus petit : 32
"""

if __name__ == '__main__':
    # Saisit les trois nombres.
    nb1 = int(input('Entrez un nombre: '))
    nb2 = int(input('Entrez un autre nombre: '))
    nb3 = int(input('Entrez un autre nombre: '))

    # Par défaut, il n'y a pas d'égalité.
    estEgal = False

    # Trouve le plus petit nombre entre le premier et deuxième.
    if nb1 < nb2:
        petit = nb1
    elif nb1 > nb2:
        petit = nb2
    else:
        #Si égalité, sauvegarde pour affichage final.
        estEgal = True
        petit = nb1

    # Compare le plus petit entre les deux premiers et le troisième.
    if petit > nb3:
        petit = nb3
        # Si le troisième est plus petit, il n'y a pas d'égalité entre les deux
        # premiers nombre.
        estEgal = False
    elif petit == nb3:
        estEgal = True

    # Affiche le résultat et notre égalité possible.
    print('Plus petit : ', petit)
    if estEgal:
        print('Il y a eu égalité.')

