"""Demande à l'utilisateur de saisir deux coordonnées. Les saisies
représente les coordonnées x et y d'un point sur un plan cartésien. Le
script affiche dans quel quadrant appartient le point. L'affichage prends
la forme "(X, Y) est dans le quadrant : QUADRANT." suivi d'un saut de
ligne. La valeur QUADRANT peut être "I", "II", "III" ou "IV".
`Quadrant Cartésiens Wikipedia <https://fr.wikipedia.org/wiki/Quadrant_(mathématiques)>`_

Example:
  ::

      Veuillez entrer la coordonnée en x: -4
      Veuillez entrer la coordonnée en y: 6
      (-4, 6) est dans le quadrant : II.
"""

if __name__ == '__main__':
    # Saisit la coordonnée en x et y.
    x = float(input('Veuillez entrer la coordonnée en x: '))
    y = float(input('Veuillez entrer la coordonnée en y: '))

    # Détermine le quadrant auquel le point appartient.
    # Note: Dans le cas d'une ambiguïté de décision, vous n'avez pas besoin de
    # considéré le cas. Par exemple, on ne traite pas le cas ou le point est
    # directement sur un des axes avec x == 0 ou y == 0.
    # Note : Nous verrons dans le prochain cours comment joindre plusieurs
    # conditions ensemble.
    if x >= 0:
        if y >= 0:
            quadrant = 'I'
        else:
            quadrant = 'IV'
    else:
        if y >= 0:
            quadrant = 'II'
        else:
            quadrant = 'III'

    # Affiche le quadrant auquel le point appartient.
    print('(', x, ',', y, ') est dans le quadrant :', quadrant)
