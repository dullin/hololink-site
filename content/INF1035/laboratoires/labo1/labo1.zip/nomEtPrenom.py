"""Demande à l’utilisateur de saisir le nom suivi du prénom de l'utilisateur
(avec deux saisis disctinctes). Le script affiche les message suivant
avec le nom et prénom de l'utilisateur "Bonjour PRENOM NOM!" suivi d'un
saut de ligne.

Example:
  ::

      Veuillez entrer votre nom: Loblaw
      Veuillez entrer votre prénom: Bob
      Bonjour Bob Loblaw!
"""

if __name__ == '__main__':
    # Saisit le prénom et le nom.
    nom = input('Veuillez entrer votre nom: ')
    prenom = input('Veuillez entrer votre prénom: ')

    # Affiche la saluation.
    print('Bonjour', prenom, nom)
