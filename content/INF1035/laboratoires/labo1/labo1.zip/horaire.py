"""Affiche l'horaire suivant dans le fenêtre de commande:

 Example:
   ::

       Horaire:
       7h00 – déjeuner
       12h00 – diner
       17h00 – souper

"""

if __name__ == '__main__':
    # Affiche l'horaire.
    print('''Horaire:
    7h00 - déjeuner
    12h00 - diner
    17h00 - souper''')
