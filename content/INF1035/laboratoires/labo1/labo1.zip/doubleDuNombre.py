"""Demande à l’utilisateur de saisir un nombre, le script affiche ensuite
le double (multiplication par 2) du nombre. L'affichage prends la forme
"Double du nombre : NOMBRE" suivi d'un saut de ligne.

Example:
  ::

      Entrez un nombre: 34
      Double du nombre : 68
"""

if __name__ == '__main__':
    # Saisit le nombre.
    nombreSaisi = int(input('Entrez un nombre: '))

    # Affiche le double du nombre saisi.
    print('Double du nombre :', 2 * nombreSaisi)
