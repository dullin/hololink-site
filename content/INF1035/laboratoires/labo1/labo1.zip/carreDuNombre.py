"""Demande à l'utilisateur de saisir un nombre, le script affiche ensuite le
nombre au carré (multiplié par lui-même). L'affichage prends la forme
"Carré du nombre : NOMBRE" suivi d'un saut de ligne.

Example:
  ::

      Entrez un nombre: 54
      Carré du nombre : 2916
"""
if __name__ == '__main__':
    # Saisit le nombre.
    nombrebSaisi = int(input('Entrez un nombre: '))

    # Affiche le carré du nombre saisi.
    print('Carré du nombre : ', nombrebSaisi ** 2)
