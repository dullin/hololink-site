# Saisit un nombre et affiche le nombre factoriel de la saisie

# Saisit le nombre.
saisi = int(input('Entrez un nombre : '))

somme = 1
nombre = 1
while nombre <= saisi:
    somme = somme * nombre
    nombre = nombre + 1

print(saisi, "! =", somme)