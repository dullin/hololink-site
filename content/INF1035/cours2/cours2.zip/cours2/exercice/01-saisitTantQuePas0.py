# Saisit un nombre à l'utilisateur et recommance la saisit tant
# que le nombre n'est pas 0.

# Première saisit
saisi = int(input('Entrez un nombre : '))

while saisi != 0:
    saisi = int(input('Entrez un nombre : '))

print('Fin du programme.')