# Script déterminant si un utilisateur est eligible au tarif réduit

# Constante d'âge du tarif réduit.
AGE_OR = 60
AGE_ENFANT = 18

# Saisit l'âge.
age = int(input('Votre age : '))

# Détermine si le tarif réduit est applicable.
if age > AGE_OR or age < AGE_ENFANT:
    print('Eligible au tarif reduit\n')
else:
    print('Pas eligible au tarif reduit\n')

