# Compte le nombre d'élèves ne pouvant pas être en equipe dans une classe.

# Saisit le nombre d'élèves et le nombre par équipe.
nombre_eleves = int(input("Le nombre d'élèves : "))
nombre_par_equipe = int(input('Le nombre par équipe : '))

if nombre_eleves % nombre_par_equipe == 0:
      print('Les groupes sont complets.')
else:
      # Utilise le mod directement dans le fprintf.
      print("Le nombre d'élèves restant sera : ",
            nombre_eleves % nombre_par_equipe, ".")
