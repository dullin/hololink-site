# Saisit une valeur n. Calcule la somme cumulative de 1 à n.

# Saisit de n
n = int(input('La valeur de n : '))

# Additionne de 1 à n
compteur = 1
somme = 0
while compteur <= n:
    somme = somme + compteur
    compteur = compteur + 1

print('La somme de 1 a', n, 'est :', somme)

