# Compte le nombre de 0 entrez au clavier sur 10 essais

# Aucun succès au depart.
succes = 0
# Essaies 10 fois
for i in range(10):
    # Saisit un nombre à l'utilisateur.
    saisit = int(input('Entrez un nombre : '))
    # Ajoute un succès si on trouve le bon nombre.
    if saisit == 0:
        succes = succes + 1
# Affiche le résultat.
print('Le nombre de succes sur 10 essais est : ',succes)