# Saisit une valeur n. Calcule la somme cumulative des nombres pairs de 1 à
# n. AVEC UN FOR.

# Saisit n
n = int(input('La valeur de n: '))

somme = 0
# Additione de 1 a n
for compteur in range (1, n+1):
    if compteur % 2 == 0:
        somme = somme + compteur

# Affiche la somme
print('La somme de 1 a', n , 'pair est : ', somme)