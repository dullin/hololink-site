# Exemple de while avec incrémentation pour éviter une boucle infinie.

x = 5

while x < 10:
    print('La valeur de x est :', x)
    x = x + 1 # Incrémentation de x

print('Fin du programme.')