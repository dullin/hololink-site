# Exemple de différentes boucles for avec affichage.

# Boucle avec une liste de valeurs
print('Boucle for simple')
for x in [1, 2, 3, 4]:
    print(x)

# Boucle avec une liste de valeurs non-ordonnées
print('Boucle non-ordonnées')
for x in [34, 56, 23, 1]:
    print(x)

# Boucle avec une liste de chaines
print('Boucle avec des chaines')
for x in ['ok', 'ah', 'non']:
    print(x)

# Boucle avec une séquence (range) de nombres
print('Boucle avec la fonction range')
# À noté que le range débute à 0 et exclus la valeur
for x in range(5):
    print(x)

# Boucle avec une spcécification de la séquence
print('Boucle avec la fonction range et un début')
# Le permier paramètre indique le début et le deuxième la fin (exclus encore)
for x in range(2,6):
    print(x)

# Boucle avec un saut définie
print('Boucle avec la fonction range, un début et un saut')
# Le dernier paramètre est utilisé pour indiquer le saut entre chaque élément
for x in range(2, 10, 3):
    print(x)