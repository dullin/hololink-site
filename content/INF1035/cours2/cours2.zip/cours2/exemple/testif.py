x = 12

if x < 10:
    print("1")
elif x < 20:
    print("2")
elif x < 15:
    print("3")
