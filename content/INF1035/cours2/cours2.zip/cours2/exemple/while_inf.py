# Exemple de while

x = 5

while x < 10:
    print('La valeur de x est : ', x)

print('Fin du programme.')